#!/usr/bin/env python3
"""Repair corrupted game.py"""

with open('game.py', 'r') as f:
    lines = f.readlines()

# Find the _build_world method and fix it
new_lines = []
skip_help_text = False

for i, line in enumerate(lines):
    # Skip the corrupted help text lines that are in _build_world
    if 'def _build_world' in line:
        new_lines.append(line)
        skip_help_text = True
    elif skip_help_text and '"== AETHER STATION COMMANDS' in line:
        # Start of corrupted help text - keep skipping
        continue
    elif skip_help_text and '"Goal: Restore power' in line:
        # End of corrupted help text
        skip_help_text = False
        continue
    elif skip_help_text and ('COMMANDS' in line or 'Navigation:' in line or 'Actions:' in line or 
                               'Game:' in line or 'Tips:' in line or 'Goal:' in line or
                               ('<<=' not in line and '"' not in line and 'A quiet' not in line)):
        continue
    elif skip_help_text and 'A quiet transit hub' in line:
        # This is the start of the real description
        skip_help_text = False
        new_lines.append('            "station": Room(\n')
        new_lines.append('                name="Aether Station",\n')
        new_lines.append('                description=(\n')
        new_lines.append(line.replace('                    ', '                    '))
    else:
        new_lines.append(line)

with open('game.py', 'w') as f:
    f.writelines(new_lines)

print("✓ Repair complete!")
