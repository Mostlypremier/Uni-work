@echo off
cd /d "%~dp0"
"C:\Users\UserPC\AppData\Local\Programs\Python\Python312\python.exe" main.py
pause
