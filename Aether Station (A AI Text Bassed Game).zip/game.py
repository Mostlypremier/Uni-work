from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from llm_local import LocalNarrator, create_narrator
from game_state import save_game, load_game, has_save, GameState


@dataclass
class Room:
    name: str
    description: str
    exits: Dict[str, str]
    items: List[str] = field(default_factory=list)
    npc: Optional[str] = None
    npc_hint: Optional[str] = None


class TextAdventure:
    def __init__(self, narrator: Optional[LocalNarrator] = None):
        self.narrator = narrator
        self.state = GameState()
        self.rooms = self._build_world()
        self.tutorial_mode = False
        self.tutorial_step = 0

    def _build_world(self) -> Dict[str, Room]:
        return {
            "station": Room(
                name="Aether Station",
                description=(
                    "A quiet transit hub under flickering lights. A sealed door leads north, "
                    "a maintenance corridor runs east, an old kiosk hums beside the platform, "
                    "and a utility door descends to the south."
                ),
                exits={"north": "vault", "east": "workshop", "south": "power_core"},
                items=["map"],
            ),
            "workshop": Room(
                name="Workshop",
                description=(
                    "Tools hang on the wall. Dusty cables snake across the floor, and a terminal "
                    "glows beside a locked drawer. A ladder descends to the west into darkness."
                ),
                exits={"west": "station", "south": "archive", "down": "control_room"},
                items=["battery"],
                npc="mechanic",
                npc_hint="The mechanic can tell you how to open the vault if you bring power to the terminal.",
            ),
            "archive": Room(
                name="Archive",
                description=(
                    "Rows of old logs and faded charts line the shelves. One shelf is slightly ajar. "
                    "Dust particles drift through shafts of pale light."
                ),
                exits={"north": "workshop"},
                items=["keycard"],
            ),
            "vault": Room(
                name="Vault Door",
                description=(
                    "A massive steel vault with a card reader and a dead control panel. The air feels colder here. "
                    "A narrow passage leads up to an observation deck."
                ),
                exits={"south": "station", "up": "observation_deck"},
                items=[],
            ),
            "control_room": Room(
                name="Control Room",
                description=(
                    "A dimly lit electrical junction filled with panels and switches. Banks of monitors are dark. "
                    "A large fusebox is mounted on the wall, and a radio crackles softly on the desk."
                ),
                exits={"up": "workshop"},
                items=["fusebox", "radio"],
                npc="technician",
                npc_hint="The technician mentions the power core needs a coolant injection to restart the reactor.",
            ),
            "power_core": Room(
                name="Power Core",
                description=(
                    "The heart of the station thrums with dormant machinery. Massive turbines loom overhead, "
                    "and a reactor coolant container sits beside the main generator. Everything is very still."
                ),
                exits={"up": "station"},
                items=["coolant"],
            ),
            "observation_deck": Room(
                name="Observation Deck",
                description=(
                    "A transparent dome reveals the void beyond. Station logs and old communications records "
                    "are scattered across a console. A weathered scientist's journal lies on a seat."
                ),
                exits={"down": "vault"},
                items=["journal"],
                npc="scientist",
                npc_hint="The scientist's notes mention a backup power sequence hidden in the station records.",
            ),
        }

    def current_room(self) -> Room:
        return self.rooms[self.state.location]

    def intro(self) -> str:
        self.state.seen_intro = True
        return (
            "You wake in Aether Station with one goal: restore power, retrieve the hidden archive, "
            "and open the vault before the station shuts down. Type 'help' for commands."
        )

    def start_tutorial(self) -> str:
        self.tutorial_mode = True
        self.tutorial_step = 0
        self.state.seen_intro = True
        return (
            "Tutorial mode enabled. I'll guide you through your first few actions.\n"
            "Step 1: type 'look' to inspect your surroundings."
        )

    def tutorial_tip(self, command: str, response: str) -> str:
        if not self.tutorial_mode:
            return response

        tip: Optional[str] = None
        normalized = command.strip().lower()

        if self.tutorial_step == 0 and normalized == "look":
            self.tutorial_step = 1
            tip = "Tutorial: Great. Now go east to the Workshop."
        elif self.tutorial_step == 1 and self.state.location == "workshop":
            self.tutorial_step = 2
            tip = "Tutorial: Good. Take the battery with 'take battery'."
        elif self.tutorial_step == 2 and normalized == "take battery" and response == "You take the battery.":
            self.tutorial_step = 3
            tip = "Tutorial: Nice. Try 'talk' to ask the mechanic for advice."
        elif self.tutorial_step == 3 and normalized == "talk":
            self.tutorial_step = 4
            tip = "Tutorial: You can save progress any time with 'save'."
        elif self.tutorial_step == 4 and normalized == "save" and response.startswith("Game saved"):
            self.tutorial_step = 5
            tip = "Tutorial complete: you're ready to explore on your own."

        if tip:
            return response + "\n\n" + tip
        return response

    def look(self) -> str:
        room = self.current_room()
        details = [f"{room.name}: {room.description}"]
        if room.items:
            details.append("You see: " + ", ".join(room.items) + ".")
        if room.npc:
            details.append(f"Someone is here: {room.npc}.")
        exits = ", ".join(sorted(room.exits.keys()))
        details.append(f"Exits: {exits}.")
        return " ".join(details)

    def move(self, direction: str) -> str:
        room = self.current_room()
        if direction not in room.exits:
            return "You can't go that way."
        self.state.location = room.exits[direction]
        return self.look()

    def take(self, item: str) -> str:
        room = self.current_room()
        if item not in room.items:
            return f"There is no {item} here."
        room.items.remove(item)
        self.state.inventory.append(item)
        return f"You take the {item}."

    def use(self, item: str) -> str:
        if item not in self.state.inventory:
            return f"You do not have a {item}."

        if item == "battery" and self.state.location == "workshop":
            self.state.powered = True
            self.state.inventory.remove("battery")
            return "You slot the battery into the terminal. The room powers up with a low mechanical hum."
        if item == "keycard" and self.state.location == "vault":
            if not self.state.powered:
                return "The card reader stays dark. The vault has no power yet."
            self.state.objective_done = True
            return "The keycard unlocks the vault. Inside, the station's secret archive is finally yours. You win."

        if item == "map":
            return "The map marks the archive below the workshop and the vault to the north."

        return f"Nothing obvious happens when you use the {item}."

    def talk(self) -> str:
        room = self.current_room()
        if room.npc:
            return room.npc_hint or f"The {room.npc} nods, but says nothing useful."
        return "There is no one to talk to here."

    def help(self) -> str:
        return (
            "== AETHER STATION COMMANDS ==\n"
            "Navigation: north, south, east, west, up, down\n"
            "Actions: look, take <item>, use <item>, talk, inventory\n"
            "Game: save, load, help, quit\n\n"
            "Tips: Talk to NPCs for hints. Read MANUAL.md for detailed guidance.\n"
            "Tutorial: Start a guided run from the launch prompt to learn the basics.\n"
            "Goal: Restore power, find archive, open vault."
        )

    def inventory(self) -> str:
        if not self.state.inventory:
            return "You are carrying nothing."
        return "You are carrying: " + ", ".join(self.state.inventory) + "."

    def summarize_state(self, command: str, outcome: str) -> str:
        room = self.current_room()
        inventory = ", ".join(self.state.inventory) or "nothing"
        return (
            "You are narrating a compact text adventure. Keep the reply under 70 words, vivid but concise. "
            f"Current location: {room.name}. Inventory: {inventory}. Player command: {command}. Outcome: {outcome}. "
            "Write a short immersive narration of the result. Do not add instructions, bullet points, or quotes."
        )

    def narrate(self, command: str, outcome: str) -> str:
        if self.narrator is None:
            return outcome
        try:
            narrative = self.narrator.generate(self.summarize_state(command, outcome))
            return narrative or outcome
        except Exception:
            return outcome

    def handle_command(self, raw: str) -> str:
        self.state.turns += 1
        command = raw.strip().lower()
        if not command:
            return "Say something, or type 'help'."

        parts = command.split()
        verb = parts[0]
        args = parts[1:]

        if verb in {"quit", "exit"}:
            return "__quit__"
        if verb == "help":
            return self.help()
        if verb == "save":
            return self.tutorial_tip(command, save_game(self.state))
        if verb == "load":
            return "__load__"
        if verb == "look":
            return self.tutorial_tip(command, self.narrate(command, self.look()))
        if verb == "inventory":
            return self.inventory()
        if verb == "talk":
            return self.tutorial_tip(command, self.narrate(command, self.talk()))
        if verb == "go" and args:
            return self.tutorial_tip(command, self.narrate(command, self.move(args[0])))
        if verb in {"north", "south", "east", "west", "up", "down"}:
            return self.tutorial_tip(command, self.narrate(command, self.move(verb)))
        if verb == "take" and args:
            return self.tutorial_tip(command, self.narrate(command, self.take(" ".join(args))))
        if verb == "use" and args:
            return self.tutorial_tip(command, self.narrate(command, self.use(" ".join(args))))

        return self.tutorial_tip(command, self.narrate(command, "I do not understand that command."))


def main() -> None:
    narrator = create_narrator()
    game = TextAdventure(narrator)

    print("Aether Station")
    if narrator is None:
        print("Local LLM not loaded. The game will still run with deterministic narration.")
        print("Set LOCAL_LLM_MODEL_PATH to a local GGUF model file to enable LLM narration.")
    else:
        print("Local LLM narration is enabled.")
    
    # Check if a save file exists and offer to load it
    if has_save():
        print("\nYou have a saved game. Type 'load' to restore it, 'new' to start fresh, or 'tutorial' for a guided run.")
        while True:
            choice = input("> ").strip().lower()
            if choice == "load":
                loaded_state = load_game()
                if loaded_state:
                    game.state = loaded_state
                    print(f"Game loaded. You are in {game.current_room().name}.")
                    print(game.look())
                    break
                else:
                    print("Failed to load save. Starting new game.")
                    print(game.intro())
                    print(game.look())
                    break
            elif choice == "tutorial":
                print(game.intro())
                print(game.start_tutorial())
                print(game.look())
                break
            elif choice == "new":
                print(game.intro())
                print(game.look())
                break
            else:
                print("Type 'load', 'new', or 'tutorial'.")
    else:
        print("Type 'new' for a normal game or 'tutorial' for a guided run.")
        while True:
            choice = input("> ").strip().lower()
            if choice == "tutorial":
                print(game.intro())
                print(game.start_tutorial())
                print(game.look())
                break
            if choice == "new":
                print(game.intro())
                print(game.look())
                break
            print("Type 'new' or 'tutorial'.")

    while True:
        raw = input("> ")
        response = game.handle_command(raw)
        if response == "__quit__":
            print("Thanks for playing.")
            break
        elif response == "__load__":
            loaded_state = load_game()
            if loaded_state:
                game.state = loaded_state
                print(f"Game loaded. You are in {game.current_room().name}.")
                print(game.look())
            else:
                print("No save file found.")
            continue
        print(response)
        if game.state.objective_done:
            print("The station is secure. You completed the mission.")
            break


if __name__ == "__main__":
    main()
