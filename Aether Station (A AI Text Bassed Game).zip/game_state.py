"""Save and load game state to/from JSON file."""

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional, List


@dataclass
class GameState:
    location: str = "station"
    inventory: List[str] = field(default_factory=list)
    objective_done: bool = False
    powered: bool = False
    turns: int = 0
    seen_intro: bool = False


SAVES_DIR = Path("saves")
SAVE_FILE = SAVES_DIR / "game_state.json"


def ensure_saves_dir() -> None:
    """Create saves directory if it doesn't exist."""
    SAVES_DIR.mkdir(exist_ok=True)


def save_game(state: GameState) -> str:
    """
    Save game state to JSON file.
    
    Args:
        state: GameState object to save
        
    Returns:
        Success or error message
    """
    ensure_saves_dir()
    try:
        data = {
            "location": state.location,
            "inventory": state.inventory,
            "objective_done": state.objective_done,
            "powered": state.powered,
            "turns": state.turns,
            "seen_intro": state.seen_intro,
        }
        with open(SAVE_FILE, "w") as f:
            json.dump(data, f, indent=2)
        return f"Game saved to {SAVE_FILE}."
    except Exception as e:
        return f"Failed to save game: {e}"


def load_game() -> Optional[GameState]:
    """
    Load game state from JSON file.
    
    Returns:
        GameState object if successful, None if save file doesn't exist or on error
    """
    if not SAVE_FILE.exists():
        return None
    
    try:
        with open(SAVE_FILE, "r") as f:
            data = json.load(f)
        
        state = GameState(
            location=data.get("location", "station"),
            inventory=data.get("inventory", []),
            objective_done=data.get("objective_done", False),
            powered=data.get("powered", False),
            turns=data.get("turns", 0),
            seen_intro=data.get("seen_intro", False),
        )
        return state
    except Exception as e:
        print(f"Error loading save file: {e}")
        return None


def has_save() -> bool:
    """Check if a save file exists."""
    return SAVE_FILE.exists()


def delete_save() -> str:
    """Delete the current save file."""
    if SAVE_FILE.exists():
        try:
            SAVE_FILE.unlink()
            return "Save file deleted."
        except Exception as e:
            return f"Failed to delete save: {e}"
    return "No save file to delete."
