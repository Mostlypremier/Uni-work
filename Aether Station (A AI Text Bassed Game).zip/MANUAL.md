# Aether Station - Complete Game Manual

## Table of Contents

1. [Quick Start](#quick-start)
2. [Controls & Commands](#controls--commands)
3. [Tutorial Mode](#tutorial-mode)
4. [World Map](#world-map)
5. [Characters & NPCs](#characters--npcs)
6. [Items & Inventory](#items--inventory)
7. [Objectives & Walkthrough](#objectives--walkthrough)
8. [Tips & Strategies](#tips--strategies)
9. [Troubleshooting](#troubleshooting)

---

## Quick Start

### Installation

1. **System Requirements**
   - Windows 10 or later
   - Python 3.10+ (already installed on your system)
   - 2GB+ free disk space (for the AI model)
   - 4GB+ RAM recommended

2. **First Run**
   - Double-click **Aether Station.lnk** on your desktop, or
   - Double-click **run_game.bat** in the project folder, or
   - Run `python main.py` from PowerShell

3. **First Time Setup**
   - The game will download the AI model (~300MB) on first launch
   - This takes 2-5 minutes depending on your internet
   - Subsequent launches are instant
   - At launch, you can choose `new` for normal play or `tutorial` for a guided run

### Objective

You wake aboard **Aether Station** with a critical mission:
1. Restore power to the station
2. Retrieve the hidden archive
3. Open the vault before the station shuts down

**Time is running out. Good luck.**

---

## Controls & Commands

### Basic Navigation

```
north     Move to the room to the north
south     Move to the room to the south
east      Move to the room to the east
west      Move to the room to the west
up        Move to the room above (climb/descend)
down      Move to the room below (descend/climb)
go north  Alternative: "go" + direction (e.g., "go east")
```

### Interaction Commands

```
look              Examine your current location
talk              Speak with any NPC in the room for hints
take <item>       Pick up an item (e.g., "take battery")
use <item>        Use an item (e.g., "use battery")
inventory         Check what you're carrying
```

### Game Management

```
save              Save your progress to a file
load              Load a previously saved game
help              Display all available commands
quit              Exit the game
```

---

## Tutorial Mode

Tutorial mode is a short guided onboarding path for new players.

### How to Start

When the game launches, type `tutorial` instead of `new`.

### What It Teaches

1. Use `look` to inspect the room
2. Move east to the Workshop
3. Take the battery
4. Talk to the mechanic
5. Save your progress

### Why It Helps

- Shows the core command loop step by step
- Introduces the workshop and NPC hint system
- Demonstrates saving before you explore on your own

### Examples

```
> take battery           # Pick up the battery
> use battery            # Use the battery (charges terminal)
> go north               # Move north
> north                  # Same as "go north" (shorthand)
> talk                   # Speak with NPC in current room
```

---

## World Map

```
                    Observation Deck
                           |
                         Vault Door
                           |
Aether Station --------- Workshop
      |                     |
      |              Archive (below)
   Power Core       Control Room (below Workshop)
```

### Rooms Overview

#### Aether Station (Central Hub)
- **Description:** A quiet transit hub with flickering lights
- **Items:** Map
- **Exits:** North to Vault Door, East to Workshop, South to Power Core
- **NPCs:** None
- **Notes:** Starting location; the map provides useful information

#### Workshop
- **Description:** Tools on walls, dusty cables, glowing terminal
- **Items:** Battery
- **Exits:** West to Station, South to Archive, Down to Control Room
- **NPCs:** Mechanic
- **Notes:** The terminal here powers up when you use the battery

#### Archive
- **Description:** Rows of old logs and faded charts
- **Items:** Keycard
- **Exits:** North to Workshop
- **NPCs:** None
- **Notes:** Contains the keycard needed for the vault

#### Control Room
- **Description:** Electrical junction with panels and dark monitors
- **Items:** Fusebox, Radio
- **Exits:** Up to Workshop
- **NPCs:** Technician
- **Notes:** Below the workshop; electrically important location

#### Power Core
- **Description:** Reactor room with dormant turbines
- **Items:** Coolant
- **Exits:** Up to Station
- **NPCs:** None
- **Notes:** South of the main station; contains reactor coolant

#### Vault Door
- **Description:** Massive steel vault with card reader
- **Items:** None
- **Exits:** South to Station, Up to Observation Deck
- **NPCs:** None
- **Notes:** Your final destination; requires keycard to open

#### Observation Deck
- **Description:** Transparent dome overlooking the void
- **Items:** Journal
- **Exits:** Down to Vault
- **NPCs:** Scientist
- **Notes:** Above the vault; offers a unique vantage point

---

## Characters & NPCs

### Mechanic (Workshop)

**Location:** Workshop

**Hint:** *"The mechanic can tell you how to open the vault if you bring power to the terminal."*

**Explanation:** The mechanic hints that you need to power up the workshop terminal. To do this:
1. Collect the battery from the Workshop
2. Use the battery (`use battery` command)
3. The terminal will power up

**Tip:** Talk to the mechanic again after powering the terminal for new information.

---

### Technician (Control Room)

**Location:** Control Room (below Workshop)

**Hint:** *"The technician mentions the power core needs a coolant injection to restart the reactor."*

**Explanation:** The technician provides critical information about the power system:
- The reactor in the Power Core requires coolant
- The coolant can be found in the Power Core room
- This is essential for fully restoring station power

**Tip:** Explore all rooms and talk to NPCs multiple times—they may have updated information as you progress.

---

### Scientist (Observation Deck)

**Location:** Observation Deck (above Vault)

**Hint:** *"The scientist's notes mention a backup power sequence hidden in the station records."*

**Explanation:** The scientist hints at an alternative power system:
- There's a backup power sequence in the station records
- The journal in this room contains clues
- Reading all NPCs' hints helps you understand the full picture

**Tip:** Visit all three NPCs before making major moves—their hints form a complete strategy.

---

## Items & Inventory

### Map
- **Location:** Aether Station (starting location)
- **Uses:** Reading it provides strategic information
- **How to Use:** `use map`
- **Effect:** Shows locations of key areas
- **Strategy:** Take this first; it's helpful for planning your route

### Battery
- **Location:** Workshop
- **Uses:** Powering the workshop terminal
- **How to Use:** `use battery` (only works in Workshop)
- **Effect:** Powers up the terminal, enabling new interactions
- **Strategy:** Essential for progression; don't lose it

### Keycard
- **Location:** Archive
- **Uses:** Unlocking the Vault Door
- **How to Use:** `use keycard` (only works at Vault)
- **Effect:** Opens the vault door; final objective
- **Strategy:** Collect after powering the terminal (hints suggest this order)

### Fusebox
- **Location:** Control Room
- **Uses:** Electrical maintenance
- **How to Use:** Part of the station restoration
- **Effect:** Supports power system restoration
- **Strategy:** Part of the technical solution to restore power

### Radio
- **Location:** Control Room
- **Uses:** Communication
- **How to Use:** Can be examined for flavor
- **Effect:** Transmits station status
- **Strategy:** Non-essential but thematic

### Coolant
- **Location:** Power Core
- **Uses:** Reactor coolant injection
- **How to Use:** Part of power restoration
- **Effect:** Critical for reactor restart
- **Strategy:** The technician mentions this; collect it

### Journal
- **Location:** Observation Deck
- **Uses:** Reading station records
- **How to Use:** `use journal`
- **Effect:** Provides background information
- **Strategy:** Read this for story context and clues

---

## Objectives & Walkthrough

### Main Objectives

1. **Restore Power to the Station**
   - Find and use the battery in the Workshop
   - Collect the coolant from the Power Core
   - Interact with the electrical systems (fusebox, terminals)

2. **Retrieve the Hidden Archive**
   - Find the keycard in the Archive room
   - The mechanic hints that this is necessary

3. **Open the Vault**
   - Use the keycard at the Vault Door
   - This completes your mission

### Optimal Route (No Spoilers)

**Phase 1: Exploration (5-10 minutes)**
- Start at Aether Station
- Pick up the map
- Talk to NPCs in each room
- Collect all items (don't worry about order yet)
- Read the journal for context

**Phase 2: Understanding the Puzzle (2-5 minutes)**
- Review NPC hints
- Analyze what each item does
- Plan your sequence based on hints

**Phase 3: Execution (2-5 minutes)**
- Power up the terminal
- Collect remaining items
- Navigate to the vault
- Use the keycard

**Phase 4: Victory**
- Mission complete!
- Your save file is preserved

### Detailed Walkthrough (Spoiler Warning)

If you get stuck, here's the complete solution:

**Step 1: Collect the Battery**
```
> go east          # Workshop
> take battery
```

**Step 2: Power the Terminal**
```
> use battery      # (in Workshop)
# Terminal powers up!
```

**Step 3: Collect the Keycard**
```
> go south         # Archive
> take keycard
```

**Step 4: Navigate to Vault**
```
> go north         # Back to Workshop
> go west          # Back to Station
> go north         # Vault Door
```

**Step 5: Open the Vault**
```
> use keycard
# Vault opens - Mission complete!
```

---

## Tips & Strategies

### General Tips

1. **Talk to Everyone First**
   - NPC hints guide you through the puzzle
   - Each character provides one key piece of information
   - Talking multiple times might reveal new hints

2. **Take Your Time**
   - There's no time limit (despite the story)
   - Explore thoroughly before acting
   - Mistakes can be undone by reloading

3. **Use Save/Load**
   - Save after significant progress
   - You can try different approaches without losing progress
   - Useful for experimenting with item combinations

4. **Read Everything**
   - Room descriptions contain clues
   - Item descriptions matter
   - NPC hints are carefully written

### Navigation Tips

1. **Mark Your Route**
   - Mentally note the connections between rooms
   - Up/down connects to vertical levels
   - North/south/east/west form a grid

2. **Return to Station**
   - Aether Station is the central hub
   - You can reach it from multiple directions
   - Good place to reorient yourself

3. **Inventory Management**
   - You can carry multiple items
   - No weight limit or carrying capacity
   - Take what you find—you'll need it all

### Puzzle Strategy

1. **Think Logically**
   - What does each item do logically?
   - Where would you logically use it?
   - The game respects real-world logic

2. **Try Everything**
   - If an action doesn't work, you'll get feedback
   - No negative consequences for trying
   - The game guides you toward solutions

3. **Use the Hints**
   - The three NPCs each hint at different aspects
   - Combine all hints to understand the full picture
   - They're not random—each is specific

---

## Troubleshooting

### Game Won't Start

**Problem:** "Python not recognized"

**Solution:**
- Use the desktop shortcut **Aether Station.lnk**
- Or double-click **run_game.bat**
- If neither works, open PowerShell and type:
  ```powershell
  & "C:\Users\UserPC\AppData\Local\Programs\Python\Python312\python.exe" main.py
  ```

---

### AI Model Download Fails

**Problem:** Game hangs or freezes during first run

**Solution:**
1. Close the game
2. Delete the `~/.cache/huggingface/hub/` directory
3. Restart and try again
4. Ensure you have 500MB free disk space

**Workaround:** If download keeps failing:
- The game runs fine without the AI model
- You'll get deterministic narration instead
- Restart the game to continue

---

### Game Runs Slowly

**Problem:** Narration takes 10+ seconds per action

**Solution:**
1. This is normal on first narration (model loads)
2. Subsequent narrations are faster
3. If too slow for your taste, you can adjust:
   ```powershell
   $env:LOCAL_LLM_MAX_TOKENS=40  # Smaller narrations
   python main.py
   ```

---

### I Can't Find an Item

**Problem:** "There is no [item] here"

**Solution:**
1. Make sure you're in the right room
2. Use `look` to see what's in the current room
3. Check the World Map section above for exact locations
4. Items don't move—they stay in their rooms

---

### I'm Stuck on the Puzzle

**Problem:** Don't know what to do next

**Solution:**
1. Talk to all NPCs—their hints are the key
2. Look at the Detailed Walkthrough section above
3. Try using each item you've collected
4. Check the Objectives section for guidance

---

### Can't Save/Load

**Problem:** Save command doesn't work

**Solution:**
1. Make sure you have write permission to the project folder
2. The `saves/` directory will be created automatically
3. Check that you have free disk space
4. Try restarting the game

---

### Existing Save Won't Load

**Problem:** "Load" command doesn't restore your game

**Solution:**
1. Check if a save file exists: Look for `saves/game_state.json`
2. If it doesn't exist, you'll need to start fresh
3. If it exists but won't load, the file may be corrupted
4. Delete `saves/game_state.json` and start a new game

---

## FAQ

**Q: How long does the game take to complete?**
A: 15-30 minutes for first playthrough. Speedrun: 5 minutes.

**Q: Can I die or get stuck?**
A: No. There are no deaths or unwinnable states. You can always load a previous save.

**Q: Is there a timer?**
A: No. The story mentions urgency, but there's no actual time limit.

**Q: What happens if I use items in the wrong order?**
A: The game gives you feedback. Some items only work in specific locations.

**Q: Can I explore without solving the puzzle?**
A: Yes! Explore first, understand the story, then solve it.

**Q: Will the AI narration be different each time?**
A: Yes! The AI generates unique narration for each action, within reason.

**Q: What if I don't want AI narration?**
A: The game works perfectly fine without it. You get deterministic narration as fallback.

**Q: Can I modify the game or add rooms?**
A: Yes! The code is open—modify `game.py` to extend the world.

**Q: Is there a story ending or epilogue?**
A: The vault opening is the ending. The mission is complete.

**Q: Can I speed up the narration?**
A: Yes, set `LOCAL_LLM_MAX_TOKENS=40` before launching.

**Q: How do I uninstall?**
A: Simply delete the project folder. Python stays on your system.

---

## Feedback & Support

If you find bugs or have suggestions:
1. Check the Troubleshooting section above
2. Verify your Python version: `python --version`
3. Check the README.md for additional setup info

---

**Enjoy your mission aboard Aether Station!**

*Last Updated: May 13, 2026*
