# Aether Station

A lightweight Python text adventure that uses a **local open-source LLM** for narration.

- No hosted API is used for the base model.
- The game works with a local model file on your own machine.
- The model is optional, so the game still runs on low-performance laptops even without it.
- Gameplay logic is deterministic and small; the LLM only adds short narrative flavor.

## Recommended model

The game auto-downloads a small quantized GGUF model on first run, or you can point it at your own local file.

Recommended model for low-performance laptops:

- `lmstudio-community/Qwen2.5-0.5B-Instruct-GGUF`
- Suggested file: `*Q4_K_M.gguf`

This is a very small CPU-friendly model, and the 4-bit quantization keeps memory use low.

## Setup

1. Install Python 3.10+.
2. Install dependencies:
   ```bash

   ## Other recommendeded models
   - `HuggingFaceTB/SmolLM2-135M`



   ## Setup

   1. Install Python 3.10+.
   2. Install dependencies:
      ```bash
      python -m pip install -r requirements.txt
      ```
   3. Run the game once and it will download the model automatically.
   4. If you want to use a different local Hugging Face model, set:
      ```powershell
      $env:LOCAL_LLM_MODEL_ID = "HuggingFaceTB/SmolLM2-135M"
      ```

   Optional tuning for slower machines:

   - `LOCAL_LLM_MAX_TOKENS=60`
   - `LOCAL_LLM_TEMPERATURE=0.7`
   - `LOCAL_LLM_TOP_P=0.9`

   If the model download is slow, the `hf_xet` support in `requirements.txt` helps Hugging Face fetch it faster.

   ## Run

   ```bash
   python main.py
   ```

   Or double-click **run_game.bat** in the project folder or use the **Aether Station** shortcut on your desktop.

   On startup, you can choose `new`, `tutorial`, or `load` (when a save exists).

   ## World

   The station has 7 interconnected areas to explore:

   - **Aether Station** (central hub) - Starting point with map and exits to all major areas
   - **Workshop** (east) - Mechanic's room, contains battery
   - **Archive** (south of workshop) - Old records, contains keycard
   - **Control Room** (below workshop) - Electrical junction with technician, contains fusebox and radio
   - **Power Core** (south of station) - Reactor room, contains coolant
   - **Vault Door** (north of station) - Goal location, requires keycard to open
   - **Observation Deck** (above vault) - Viewing dome with scientist, contains journal

   ### NPCs

   Talk to NPCs for hints about the mission:
   - **Mechanic** (Workshop) - Hints about powering the terminal
   - **Technician** (Control Room) - Information about the reactor coolant system
   - **Scientist** (Observation Deck) - Notes about backup power sequences

   ## Commands

   - `look` - Examine your current location
   - `go north|south|east|west|up|down` - Navigate to adjacent rooms
   - `take <item>` - Pick up an item
   - `use <item>` - Use an item (battery powers terminal, keycard opens vault)
   - `talk` - Speak with NPCs for hints
   - `inventory` - Check what you're carrying
   - `save` - Save your current progress (inventory, location, objectives)
   - `load` - Load a previously saved game
   - `tutorial` - Start a guided beginner run from the launch prompt
   - `help` - Show all available commands
   - `quit` - Exit the game

   ## Save/Load Game

   Your progress is automatically saved when you use the `save` command:

   ```bash
   > save
   Game saved to saves\game_state.json.
   ```

   When you restart the game, it will detect a saved game and offer to restore it:

   ```
   You have a saved game. Type 'load' to restore it, 'new' to start fresh, or 'tutorial' for a guided run.
   ```

   If no save exists, the game still offers `new` or `tutorial` at launch.

   You can also use the `load` command during gameplay to restore a saved state.

   Saved games persist in the `saves/` directory and are stored as JSON files.

   ## Notes

   - The game falls back to built-in narration if the model is unavailable.
   - The model is only loaded locally for inference.
