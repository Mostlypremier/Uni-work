from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Optional


@dataclass
class LLMConfig:
    model_id: str = "HuggingFaceTB/SmolLM2-135M"
    temperature: float = 0.8
    max_tokens: int = 80
    top_p: float = 0.9


class LocalNarrator:
    def __init__(self, config: LLMConfig):
        self.config = config
        self._tokenizer = None
        self._model = None

    @property
    def available(self) -> bool:
        return self._model is not None and self._tokenizer is not None

    def load(self) -> None:
        if self.available:
            return

        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer

        self._tokenizer = AutoTokenizer.from_pretrained(self.config.model_id)
        self._model = AutoModelForCausalLM.from_pretrained(
            self.config.model_id,
            torch_dtype=torch.float32,
            low_cpu_mem_usage=True,
        ).to("cpu")
        self._model.eval()

        if self._tokenizer.pad_token_id is None and self._tokenizer.eos_token_id is not None:
            self._tokenizer.pad_token = self._tokenizer.eos_token

    def _build_prompt(self, prompt: str) -> str:
        return (
            "You are the narrator of a small text adventure.\n"
            "Keep responses vivid, clear, and under 60 words.\n\n"
            f"{prompt}\n\nNarration:"
        )

    def generate(self, prompt: str) -> str:
        if not self.available:
            self.load()

        import torch

        assert self._model is not None
        assert self._tokenizer is not None

        full_prompt = self._build_prompt(prompt)
        inputs = self._tokenizer(full_prompt, return_tensors="pt")
        input_length = inputs["input_ids"].shape[-1]

        with torch.inference_mode():
            output_ids = self._model.generate(
                **inputs,
                max_new_tokens=self.config.max_tokens,
                do_sample=True,
                temperature=self.config.temperature,
                top_p=self.config.top_p,
                pad_token_id=self._tokenizer.eos_token_id,
            )

        generated_text = self._tokenizer.decode(
            output_ids[0][input_length:],
            skip_special_tokens=True,
        ).strip()
        return generated_text or "The storyteller falls silent."


def create_narrator() -> Optional[LocalNarrator]:
    model_id = os.environ.get("LOCAL_LLM_MODEL_ID", "").strip() or "HuggingFaceTB/SmolLM2-135M"

    config = LLMConfig(
        model_id=model_id,
        temperature=float(os.environ.get("LOCAL_LLM_TEMPERATURE", "0.8")),
        max_tokens=int(os.environ.get("LOCAL_LLM_MAX_TOKENS", "80")),
        top_p=float(os.environ.get("LOCAL_LLM_TOP_P", "0.9")),
    )

    narrator = LocalNarrator(config)
    try:
        narrator.load()
    except Exception:
        return None
    return narrator
